PoC bundle README
-----------------
This bundle contains a small express server and static demo pages to demonstrate:
 - Elements Panel: change hidden inputs (vuln.html form)
 - Console Panel: override fetch/validation (use console to monkeypatch)
 - Sources Panel: pretty-print app.min.js and set breakpoints / edit runtime code
 - Network Panel: Edit & Resend network requests or use fetch in page
 - Application Panel: Inspect localStorage, cookies, and tokens (login endpoint sets accessible cookie)
 - Performance Panel: Race demo (/api/slow-transfer)
 - Memory Panel: Leak demo (detached nodes retained by closures)
 - Network (Socket): WebSocket echo server and client (ws)

How to run:
 1) Install Node.js (v14+)
 2) cd browser_pentest_pocs_updated
 3) npm install
 4) npm start
 5) Open http://localhost:3000/ in your browser (use an incognito window for clean state)

Safety:
 - This PoC is intentionally insecure for teaching. Run locally and do not expose to public networks.
